"""
chunker.py
----------
Splits scraped pages into smaller overlapping chunks suitable for
embedding + retrieval.

Usage:
    python chunker.py

Reads:  data/scraped_pages.json
Writes: data/chunks.json
    A list of {"id": ..., "url": ..., "title": ..., "text": ...} objects.
"""

import json
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
INPUT_FILE = DATA_DIR / "scraped_pages.json"
OUTPUT_FILE = DATA_DIR / "chunks.json"

CHUNK_SIZE_WORDS = 180
CHUNK_OVERLAP_WORDS = 30


def chunk_text(text: str, size: int = CHUNK_SIZE_WORDS, overlap: int = CHUNK_OVERLAP_WORDS) -> list[str]:
    words = text.split()
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = start + size
        chunk_words = words[start:end]
        chunks.append(" ".join(chunk_words))
        if end >= len(words):
            break
        start = end - overlap  # overlap keeps context across chunk boundaries

    return chunks


def main():
    if not INPUT_FILE.exists():
        print(f"{INPUT_FILE} not found. Run scraper.py first.")
        return

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        pages = json.load(f)

    all_chunks = []
    chunk_id = 0

    for page in pages:
        text_chunks = chunk_text(page["text"])
        for ct in text_chunks:
            all_chunks.append({
                "id": chunk_id,
                "url": page["url"],
                "title": page["title"],
                "text": ct,
            })
            chunk_id += 1

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(all_chunks, f, indent=2, ensure_ascii=False)

    print(f"Created {len(all_chunks)} chunks from {len(pages)} pages -> {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
