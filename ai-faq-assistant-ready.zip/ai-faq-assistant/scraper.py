"""
scraper.py
----------
Scrapes text content from one or more web pages and saves it as JSON
for the chunking/embedding pipeline.

Usage:
    python scraper.py https://example.com/faq https://example.com/help

If no URLs are passed on the command line, it falls back to TARGET_URL
in your .env file.

Output:
    data/scraped_pages.json
    A list of {"url": ..., "title": ..., "text": ...} objects.

NOTE: Always check a site's robots.txt and terms of service before
scraping. Only scrape sites you have permission to use.
"""

import sys
import json
import time
import os
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv

load_dotenv()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; FAQAssistantBot/1.0; +https://example.com/bot)"
}

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)
OUTPUT_FILE = DATA_DIR / "scraped_pages.json"


def fetch_page(url: str) -> str | None:
    try:
        resp = requests.get(url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
        return resp.text
    except requests.RequestException as e:
        print(f"  [!] Failed to fetch {url}: {e}")
        return None


def clean_text(soup: BeautifulSoup) -> str:
    """Remove nav/script/style/footer noise and return readable text."""
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript"]):
        tag.decompose()

    # Prefer <main> or elements that look like FAQ/content containers
    main = soup.find("main") or soup.find("article") or soup.body or soup

    text = main.get_text(separator="\n")
    lines = [line.strip() for line in text.splitlines()]
    lines = [line for line in lines if line]
    return "\n".join(lines)


def scrape_url(url: str) -> dict | None:
    print(f"Scraping: {url}")
    html = fetch_page(url)
    if not html:
        return None

    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.string.strip() if soup.title and soup.title.string else url
    text = clean_text(soup)

    if len(text) < 50:
        print(f"  [!] Very little text found on {url}, skipping")
        return None

    return {"url": url, "title": title, "text": text}


def find_internal_links(base_url: str, html: str, limit: int = 20) -> list[str]:
    """Optional helper: discover more FAQ-like links on the same domain."""
    from urllib.parse import urljoin, urlparse

    soup = BeautifulSoup(html, "html.parser")
    base_domain = urlparse(base_url).netloc
    links = set()

    for a in soup.find_all("a", href=True):
        full_url = urljoin(base_url, a["href"])
        parsed = urlparse(full_url)
        if parsed.netloc == base_domain and parsed.scheme.startswith("http"):
            # crude filter for FAQ/help-like pages
            if any(k in full_url.lower() for k in ["faq", "help", "support", "question"]):
                links.add(full_url.split("#")[0])
        if len(links) >= limit:
            break

    return list(links)


def main():
    urls = sys.argv[1:]
    if not urls:
        target = os.getenv("TARGET_URL")
        if not target:
            print("No URLs given and TARGET_URL not set in .env. Exiting.")
            sys.exit(1)
        urls = [target]

    results = []
    seen = set()
    queue = list(urls)

    while queue:
        url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)

        page = scrape_url(url)
        if page:
            results.append(page)

        time.sleep(0.5)  # be polite to the server

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print(f"\nSaved {len(results)} pages to {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
