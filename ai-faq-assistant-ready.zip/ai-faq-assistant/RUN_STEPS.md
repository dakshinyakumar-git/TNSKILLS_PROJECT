# How to run and record the demo (Windows / Mac / Linux)

Use Python 3.10, 3.11 or 3.12. (3.13 may not have wheels for the pinned faiss-cpu.)

You need THREE terminal windows. Start your screen recorder first.

## Terminal 1 - setup
Windows (PowerShell):
    python -m venv venv
    venv\Scripts\activate
Mac / Linux:
    python3 -m venv venv
    source venv/bin/activate

Then (all systems):
    pip install -r requirements.txt

Create your env file:
    Windows:    copy .env.example .env
    Mac/Linux:  cp .env.example .env
Open .env in an editor and replace your_api_key_here with your own key.
(Do NOT show the .env file in the recording.)

## Terminal 2 - sample FAQ website (keep it running)
    python -m http.server 8000 --directory sample_site
Open http://localhost:8000/faq.html in the browser to show the FAQ page.

## Terminal 1 - run the pipeline
    python scraper.py       # creates data/scraped_pages.json
    python chunker.py       # creates data/chunks.json
    python embed_store.py   # first run downloads the model (~80MB), creates data/faiss.index
    python app.py           # starts Flask on port 5000 (keep it running)

## Terminal 3 - ask questions (activate the venv here too)
    python ask_demo.py
or one question:
    python ask_demo.py "How can I track my order?"

Health check in browser: http://localhost:5000/health

## Do NOT show in the recording
The .env file, your API key, or the console.anthropic.com key page.
