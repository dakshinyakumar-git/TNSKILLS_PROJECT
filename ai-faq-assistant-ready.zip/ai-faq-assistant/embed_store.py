"""
embed_store.py
---------------
Builds a FAISS vector index from data/chunks.json, and provides a
search() function used by app.py at query time.

Usage (build the index once, or whenever your content changes):
    python embed_store.py

This uses sentence-transformers' all-MiniLM-L6-v2 model, which runs
locally on CPU (no API key needed) and produces 384-dimensional
embeddings.
"""

import json
from pathlib import Path

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

DATA_DIR = Path(__file__).parent / "data"
CHUNKS_FILE = DATA_DIR / "chunks.json"
INDEX_FILE = DATA_DIR / "faiss.index"
META_FILE = DATA_DIR / "chunk_meta.json"

MODEL_NAME = "all-MiniLM-L6-v2"

_model = None


def get_model() -> SentenceTransformer:
    global _model
    if _model is None:
        print(f"Loading embedding model: {MODEL_NAME} (first run downloads it)...")
        _model = SentenceTransformer(MODEL_NAME)
    return _model


def build_index():
    if not CHUNKS_FILE.exists():
        print(f"{CHUNKS_FILE} not found. Run scraper.py then chunker.py first.")
        return

    with open(CHUNKS_FILE, "r", encoding="utf-8") as f:
        chunks = json.load(f)

    if not chunks:
        print("No chunks to index.")
        return

    model = get_model()
    texts = [c["text"] for c in chunks]

    print(f"Embedding {len(texts)} chunks...")
    embeddings = model.encode(texts, show_progress_bar=True, convert_to_numpy=True)
    embeddings = embeddings.astype("float32")

    # Normalize so inner product = cosine similarity
    faiss.normalize_L2(embeddings)

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    faiss.write_index(index, str(INDEX_FILE))

    # Store metadata (text/url/title) aligned with index positions
    with open(META_FILE, "w", encoding="utf-8") as f:
        json.dump(chunks, f, indent=2, ensure_ascii=False)

    print(f"Built FAISS index with {index.ntotal} vectors -> {INDEX_FILE}")


_index = None
_meta = None


def load_index():
    global _index, _meta
    if _index is None:
        if not INDEX_FILE.exists():
            raise FileNotFoundError(
                "faiss.index not found. Run `python embed_store.py` to build it first."
            )
        _index = faiss.read_index(str(INDEX_FILE))
        with open(META_FILE, "r", encoding="utf-8") as f:
            _meta = json.load(f)
    return _index, _meta


def search(query: str, top_k: int = 4) -> list[dict]:
    """Return the top_k most relevant chunks for a query, with scores."""
    index, meta = load_index()
    model = get_model()

    query_vec = model.encode([query], convert_to_numpy=True).astype("float32")
    faiss.normalize_L2(query_vec)

    scores, indices = index.search(query_vec, top_k)

    results = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        chunk = meta[idx]
        results.append({
            "text": chunk["text"],
            "url": chunk["url"],
            "title": chunk["title"],
            "score": float(score),
        })

    return results


if __name__ == "__main__":
    build_index()
