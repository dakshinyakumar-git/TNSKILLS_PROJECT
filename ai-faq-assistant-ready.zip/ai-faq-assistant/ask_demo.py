"""
ask_demo.py - sends questions to the running Flask API and prints the result.
Works the same on Windows / Mac / Linux (no curl quoting problems).

Usage:
    python ask_demo.py "How do I reset my password?"
    python ask_demo.py            # asks the two default demo questions
"""
import sys
import textwrap
import requests

API_URL = "http://localhost:5000/ask"
DEFAULT_QUESTIONS = ["How do I reset my password?", "What is your return policy?"]


def ask(question: str):
    print("=" * 70)
    print(f"QUESTION: {question}")
    print("=" * 70)
    r = requests.post(API_URL, json={"question": question, "include_context": True}, timeout=120)
    data = r.json()
    if "error" in data:
        print("ERROR:", data["error"])
        return
    print("\n--- Retrieved context (top matches) ---")
    for i, c in enumerate(data.get("context", []), 1):
        snippet = textwrap.shorten(c["text"], width=160, placeholder=" ...")
        print(f"[{i}] score={c['score']}  {c['title']}\n    {snippet}")
    print("\n--- AI answer ---")
    print(textwrap.fill(data["answer"], width=90))
    print("\n--- Sources ---")
    for s in data.get("sources", []):
        print(f"* {s['title']} | {s['url']} | score={s['score']}")
    print()


if __name__ == "__main__":
    for q in (sys.argv[1:] or DEFAULT_QUESTIONS):
        ask(q)
