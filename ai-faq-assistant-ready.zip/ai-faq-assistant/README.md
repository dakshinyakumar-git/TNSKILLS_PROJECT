# AI FAQ Assistant API

A Retrieval-Augmented Generation (RAG) API that scrapes FAQ content from a
website, indexes it with embeddings, and answers user questions using an
LLM grounded in that content.

## How it works

```
Website  --scraper.py-->  scraped_pages.json
                                |
                          chunker.py
                                |
                          chunks.json
                                |
                        embed_store.py  --> FAISS index (local vector search)
                                |
User question --> app.py (/ask) --> embed_store.search() --> top matching chunks
                                                        --> Claude API --> answer
```

## Setup

1. **Create a virtual environment and install dependencies**

   ```bash
   python -m venv venv
   source venv/bin/activate      # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Configure your environment**

   ```bash
   cp .env.example .env
   ```

   Edit `.env` and add:
   - `ANTHROPIC_API_KEY` — your Claude API key (console.anthropic.com)
   - `TARGET_URL` — the FAQ/help page you want to scrape (optional if you
     pass URLs directly to the scraper)

3. **Scrape your FAQ content**

   ```bash
   python scraper.py https://yoursite.com/faq
   ```

   You can pass multiple URLs. This saves `data/scraped_pages.json`.

   > ⚠️ Only scrape sites you have permission to use, and respect
   > `robots.txt` and terms of service. This is required for the academic
   > integrity/ethics section of most final year project reports too.

4. **Chunk the content**

   ```bash
   python chunker.py
   ```

   This saves `data/chunks.json`.

5. **Build the embedding index**

   ```bash
   python embed_store.py
   ```

   First run downloads the `all-MiniLM-L6-v2` model (~80MB) automatically.
   This saves `data/faiss.index` and `data/chunk_meta.json`.

6. **Run the API**

   ```bash
   python app.py
   ```

7. **Ask a question**

   ```bash
   curl -X POST http://localhost:5000/ask \
        -H "Content-Type: application/json" \
        -d '{"question": "How do I reset my password?"}'
   ```

   Response:
   ```json
   {
     "answer": "You can reset your password by ...",
     "sources": [
       {"title": "Account FAQ", "url": "https://yoursite.com/faq#password", "score": 0.812}
     ]
   }
   ```

## Project structure

```
ai-faq-assistant/
├── app.py            # Flask API (the /ask endpoint)
├── scraper.py         # Scrapes website content into JSON
├── chunker.py          # Splits pages into passages
├── embed_store.py       # Builds + queries the FAISS vector index
├── requirements.txt
├── .env.example
└── data/               # scraped_pages.json, chunks.json, faiss.index, etc.
```

## Ideas for extending it (good for your report's "future work" section)

- Swap FAISS for ChromaDB or a hosted vector DB (Pinecone, Weaviate) to
  show you understand production alternatives.
- Add a `/feedback` endpoint so users can flag wrong answers — useful for
  an evaluation chapter.
- Add conversation memory so it's a multi-turn chatbot, not just single-Q&A.
- Add a simple HTML/React frontend chat widget on top of the API.
- Schedule the scraper to re-run periodically (cron / APScheduler) so the
  knowledge base stays fresh.
- Add authentication (API keys) if you deploy this publicly.
- Write evaluation tests: precision of retrieval (does it find the right
  chunk?) and answer quality (does the LLM ground its answer correctly?).

## Notes for your report

- This is a **RAG (Retrieval-Augmented Generation)** system: instead of
  fine-tuning a model on your FAQ data, you retrieve relevant text at
  query time and feed it to the LLM as context. This avoids hallucination
  and lets you update content just by re-scraping — no retraining needed.
- Embeddings turn text into vectors where semantically similar text ends
  up close together in vector space, which is why "How do I reset my
  password?" can match a chunk that says "forgot password" even without
  exact keyword overlap.
