"""
app.py
------
Flask API for the AI FAQ Assistant.

Endpoints:
    GET  /health            -> quick check that the server is up
    POST /ask                -> {"question": "..."} -> {"answer": ..., "sources": [...]}

Run:
    python app.py
Then:
    curl -X POST http://localhost:5000/ask \
         -H "Content-Type: application/json" \
         -d '{"question": "How do I reset my password?"}'
"""

import os
from flask import Flask, request, jsonify
from dotenv import load_dotenv

import embed_store

load_dotenv()

app = Flask(__name__)

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
TOP_K = 4
MIN_SCORE = 0.25  # below this similarity, we treat retrieval as "no good match"

# Lazily create the Anthropic client so the app can still boot / be tested
# even before a key is configured.
_client = None


def get_client():
    global _client
    if _client is None:
        if not ANTHROPIC_API_KEY:
            raise RuntimeError(
                "ANTHROPIC_API_KEY not set. Copy .env.example to .env and add your key."
            )
        import anthropic
        _client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    return _client


SYSTEM_PROMPT = (
    "You are a helpful FAQ assistant. Answer the user's question using ONLY "
    "the provided context passages. If the context does not contain the "
    "answer, say you don't have that information and suggest they contact "
    "support, rather than guessing. Keep answers concise and direct."
)


def build_prompt(question: str, contexts: list[dict]) -> str:
    context_block = "\n\n".join(
        f"[Source {i+1}: {c['title']} ({c['url']})]\n{c['text']}"
        for i, c in enumerate(contexts)
    )
    return (
        f"Context passages:\n{context_block}\n\n"
        f"Question: {question}\n\n"
        "Answer using only the context above. Mention which source(s) you used."
    )


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    include_context = bool(data.get("include_context"))

    if not question:
        return jsonify({"error": "Missing 'question' in request body"}), 400

    try:
        results = embed_store.search(question, top_k=TOP_K)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 500

    good_results = [r for r in results if r["score"] >= MIN_SCORE]

    if not good_results:
        return jsonify({
            "answer": "I don't have information about that in my FAQ knowledge base. "
                       "Please contact support for help with this question.",
            "sources": [],
        })

    try:
        client = get_client()
        prompt = build_prompt(question, good_results)

        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=500,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        answer_text = "".join(
            block.text for block in response.content if block.type == "text"
        )
    except Exception as e:
        return jsonify({"error": f"LLM generation failed: {e}"}), 500

    response_body = {
        "answer": answer_text,
        "sources": [{"title": r["title"], "url": r["url"], "score": round(r["score"], 3)} for r in good_results],
    }
    if include_context:
        # Optional: expose the retrieved passages (useful for demos / debugging)
        response_body["context"] = [
            {"title": r["title"], "url": r["url"], "score": round(r["score"], 3), "text": r["text"]}
            for r in good_results
        ]
    return jsonify(response_body)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
